package com.example.lista_de_tarefas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
